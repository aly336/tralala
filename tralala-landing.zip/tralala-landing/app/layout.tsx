import type { Metadata, Viewport } from "next";
import { Bricolage_Grotesque, Figtree } from "next/font/google";
import "./globals.css";
import { brand } from "@/lib/content";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const body = Figtree({ subsets: ["latin"], variable: "--font-body", display: "swap" });

const title = "Tralalá | Lanches e Burguers em Contagem - MG";
const description = "Hambúrgueres, cachorro-quente e salgados caprichados no bairro Ressaca, em Contagem. Nota 4,8 no Google. Peça pelo WhatsApp (31) 99164-7631.";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
  title,
  description,
  alternates: { canonical: "/" },
  openGraph: { title, description, locale: "pt_BR", type: "website" },
};
export const viewport: Viewport = { themeColor: "#000000" };

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  name: brand.name,
  servesCuisine: ["Hambúrguer", "Lanches", "Fast food"],
  telephone: "+5531991647631",
  priceRange: "R$ 20–40",
  hasMenu: brand.menu,
  sameAs: [brand.insta],
  address: { "@type": "PostalAddress", streetAddress: "R. Rodrigues da Cunha, 790B - Ressaca", addressLocality: "Contagem", addressRegion: "MG", postalCode: "32113-340", addressCountry: "BR" },
  aggregateRating: { "@type": "AggregateRating", ratingValue: "4.8", reviewCount: "462" },
  openingHoursSpecification: [
    { "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], opens: "16:00", closes: "00:40" },
    { "@type": "OpeningHoursSpecification", dayOfWeek: "Sunday", opens: "18:00", closes: "00:40" },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${display.variable} ${body.variable}`}>
      <body>
        <a href="#conteudo" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-gold focus:px-4 focus:py-2 focus:font-semibold">Ir para o conteúdo</a>
        {children}
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </body>
    </html>
  );
}
