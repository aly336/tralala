import { Header } from "@/components/header";
import { Hero } from "@/components/hero";
import { Benefits, Faq, FinalCta, Footer, Highlights, Insta, Local, Menu, Proof } from "@/components/sections";

export default function Page() {
  return (
    <>
      <Header />
      <main id="conteudo">
        <Hero />
        <Proof />
        <Benefits />
        <Highlights />
        <Insta />
        <Menu />
        <Local />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
    </>
  );
}
