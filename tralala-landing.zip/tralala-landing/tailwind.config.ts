import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { ink: "#000000", paper: "#F4F4F0", gold: { DEFAULT: "#FFC20E", deep: "#C98F00" } },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        soft: "0 1px 2px rgba(0,0,0,.05), 0 14px 34px -14px rgba(0,0,0,.22)",
        glow: "0 12px 36px -10px rgba(255,194,14,.6)",
      },
      keyframes: {
        "accordion-down": { from: { height: "0" }, to: { height: "var(--radix-accordion-content-height)" } },
        "accordion-up": { from: { height: "var(--radix-accordion-content-height)" }, to: { height: "0" } },
      },
      animation: { "accordion-down": "accordion-down .25s ease-out", "accordion-up": "accordion-up .25s ease-out" },
    },
  },
  plugins: [],
} satisfies Config;
