"use client";
import * as A from "@radix-ui/react-accordion";
import { Plus } from "lucide-react";
import type { ComponentProps } from "react";
import { cn } from "@/lib/utils";

export const Accordion = A.Root;

export function AccordionItem({ className, ...p }: ComponentProps<typeof A.Item>) {
  return <A.Item className={cn("rounded-2xl border border-black/10 bg-white px-6 shadow-soft", className)} {...p} />;
}

export function AccordionTrigger({ className, children, ...p }: ComponentProps<typeof A.Trigger>) {
  return (
    <A.Header className="flex">
      <A.Trigger className={cn("group flex flex-1 items-center justify-between gap-4 py-5 text-left font-display text-lg font-semibold focus-visible:outline-none focus-visible:underline", className)} {...p}>
        {children}
        <Plus className="size-5 shrink-0 text-black/50 transition-transform duration-300 group-data-[state=open]:rotate-45" />
      </A.Trigger>
    </A.Header>
  );
}

export function AccordionContent({ children, ...p }: ComponentProps<typeof A.Content>) {
  return (
    <A.Content className="overflow-hidden text-black/70 data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down" {...p}>
      <div className="pb-5">{children}</div>
    </A.Content>
  );
}
