import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export const buttonVariants = cva(
  "group inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black focus-visible:ring-offset-2",
  {
    variants: {
      variant: {
        gold: "bg-gold text-black shadow-glow hover:bg-[#ffd13d]",
        dark: "bg-black text-white hover:bg-black/80",
        outline: "border border-black/15 bg-white/60 text-black backdrop-blur hover:bg-white",
        light: "border border-white/20 bg-white/5 text-white hover:bg-white/10",
      },
      size: { md: "h-11 px-5 text-sm", lg: "h-14 px-7 text-base" },
    },
    defaultVariants: { variant: "gold", size: "md" },
  }
);

export function Button({ className, variant, size, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants>) {
  return <button className={cn(buttonVariants({ variant, size }), className)} {...p} />;
}
