"use client";
import { useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { Flame, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { LinkButton } from "@/components/shared";
import { waLink } from "@/lib/content";

const links = [
  ["Avaliações", "#avaliacoes"],
  ["Destaques", "#destaques"],
  ["Instagram", "#instagram"],
  ["Cardápio", "#cardapio"],
  ["Onde fica", "#local"],
  ["Dúvidas", "#faq"],
];

export function Header() {
  const { scrollY } = useScroll();
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  useMotionValueEvent(scrollY, "change", (y) => setSolid(y > 24));
  return (
    <motion.header
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className={cn("fixed inset-x-0 top-0 z-50 transition-[background-color,box-shadow] duration-300", solid || open ? "bg-paper shadow-soft" : "bg-paper/40 backdrop-blur-xl")}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#topo" className="flex items-center gap-2 font-display text-xl font-extrabold tracking-tight">
          <span className="grid size-8 place-items-center rounded-xl bg-black text-gold"><Flame className="size-4" aria-hidden /></span>
          Tralalá
        </a>
        <nav aria-label="Principal" className="hidden items-center md:flex">
          {links.map(([l, h]) => (
            <a key={h} href={h} className="group relative px-3 py-2 text-sm font-medium text-black/70 transition-colors hover:text-black">
              {l}
              <span className="absolute inset-x-3 bottom-1 h-0.5 origin-left scale-x-0 rounded bg-gold transition-transform duration-300 group-hover:scale-x-100" />
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <LinkButton href={waLink()} className="hidden sm:inline-flex">Pedir agora</LinkButton>
          <button className="grid size-11 place-items-center rounded-full md:hidden" aria-label={open ? "Fechar menu" : "Abrir menu"} aria-expanded={open} onClick={() => setOpen(!open)}>
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav aria-label="Menu mobile" initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden md:hidden">
            <div className="flex flex-col gap-1 px-5 pb-5">
              {links.map(([l, h]) => (
                <a key={h} href={h} onClick={() => setOpen(false)} className="rounded-xl px-3 py-3 font-display text-lg font-semibold active:bg-gold/30">{l}</a>
              ))}
              <LinkButton href={waLink()} size="lg" className="mt-2">Pedir pelo WhatsApp</LinkButton>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
