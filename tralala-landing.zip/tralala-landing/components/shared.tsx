"use client";
import { useEffect, useRef, useState, type ReactNode } from "react";
import Image from "next/image";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { Beef } from "lucide-react";
import type { VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

/** Scroll reveal: y 20 -> 0 + fade */
export function Reveal({ children, delay = 0, className }: { children: ReactNode; delay?: number; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? false : { opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/** Seção com fade-in na entrada e fade-out na saída, ligado ao scroll */
export function Section({ id, className, children }: { id?: string; className?: string; children: ReactNode }) {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const opacity = useTransform(scrollYProgress, [0, 0.1, 0.9, 1], [0, 1, 1, 0]);
  return (
    <motion.section ref={ref} id={id} style={reduce ? undefined : { opacity }} className={cn("relative", className)}>
      {children}
    </motion.section>
  );
}

type LinkProps = VariantProps<typeof buttonVariants> & { href: string; className?: string; children: ReactNode };

export function LinkButton({ href, variant, size, className, children }: LinkProps) {
  const ext = href.startsWith("http");
  return (
    <motion.a
      href={href}
      {...(ext ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.97 }}
      className={cn(buttonVariants({ variant, size }), (variant ?? "gold") === "gold" && "shimmer", className)}
    >
      {children}
    </motion.a>
  );
}

/** Foto com reserva elegante quando o arquivo ainda não existe */
export function ImageSlot({ src, alt, label, className, priority }: { src?: string; alt: string; label?: string; className?: string; priority?: boolean }) {
  const [bad, setBad] = useState(false);
  return (
    <div className={cn("relative overflow-hidden bg-black", className)}>
      {src && !bad ? (
        <Image src={src} alt={alt} fill priority={priority} sizes="(min-width:1024px) 40vw, 90vw" className="object-cover" onError={() => setBad(true)} />
      ) : (
        <div role="img" aria-label={alt} className="mesh-dark absolute inset-0 grid place-items-center">
          <div className="flex flex-col items-center gap-2 px-4 text-center text-xs text-white/40">
            <Beef className="size-8 text-gold/70" aria-hidden />
            {label}
          </div>
        </div>
      )}
    </div>
  );
}

export function useOpenStatus() {
  const [s, setS] = useState<{ open: boolean; text: string } | null>(null);
  useEffect(() => {
    const calc = () => {
      const p = new Intl.DateTimeFormat("en-US", { timeZone: "America/Sao_Paulo", weekday: "short", hour: "numeric", minute: "numeric", hourCycle: "h23" }).formatToParts(new Date());
      const g = (t: string) => p.find((x) => x.type === t)?.value ?? "0";
      const m = Number(g("hour")) * 60 + Number(g("minute"));
      const start = (g("weekday") === "Sun" ? 18 : 16) * 60;
      const open = m < 40 || m >= start;
      setS({ open, text: open ? "Aberto agora, até 00h40" : `Abre hoje às ${start / 60}h` });
    };
    calc();
    const t = setInterval(calc, 60000);
    return () => clearInterval(t);
  }, []);
  return s;
}

export function OpenPill({ className }: { className?: string }) {
  const s = useOpenStatus() ?? { open: false, text: "Seg a Sáb a partir das 16h" };
  return (
    <span className={cn("inline-flex items-center gap-2 rounded-full border border-black/10 bg-white/70 px-3.5 py-1.5 text-sm font-semibold backdrop-blur", className)}>
      <span className="relative flex size-2.5">
        {s.open && <span className="absolute inline-flex size-full animate-ping rounded-full bg-green-500 opacity-60" />}
        <span className={cn("relative inline-flex size-2.5 rounded-full", s.open ? "bg-green-500" : "bg-black/40")} />
      </span>
      {s.text}
    </span>
  );
}
