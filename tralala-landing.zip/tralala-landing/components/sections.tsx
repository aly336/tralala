"use client";
import { useRef, type ReactNode } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Beef, Camera, ChevronLeft, ChevronRight, Clock, Flame, MapPin, MessageCircle, Navigation, Phone, Play, Smile, UtensilsCrossed } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ImageSlot, LinkButton, OpenPill, Reveal, Section } from "@/components/shared";
import { brand, img, mapEmbed, routeLink, waLink } from "@/lib/content";
import { cn } from "@/lib/utils";

const wrap = "mx-auto max-w-6xl px-5";

function Head({ title, text, dark, action }: { title: string; text?: string; dark?: boolean; action?: ReactNode }) {
  return (
    <Reveal className="mb-10 flex flex-wrap items-end justify-between gap-6">
      <div className="max-w-2xl">
        <h2 className="font-display text-4xl font-extrabold leading-[1.02] tracking-tight sm:text-5xl">{title}</h2>
        {text && <p className={cn("mt-4 text-lg", dark ? "text-white/60" : "text-black/60")}>{text}</p>}
      </div>
      {action}
    </Reveal>
  );
}

/* ---------- Avaliações ---------- */
const reviews = [
  "Uma experiência muito boa, sanduíche muito gostoso e o ambiente é ótimo!!!!",
  "Fiz o primeiro pedido hoje de dois salgados pelo aplicativo da loja.",
  "Comida saborosa, em boas quantidades e qualidades, super recomendo!",
];

export function Proof() {
  const rail = useRef<HTMLDivElement>(null);
  const go = (d: number) => rail.current?.scrollBy({ left: d * rail.current.clientWidth * 0.7, behavior: "smooth" });
  const arrow = "grid size-11 place-items-center rounded-full border border-white/15 transition hover:border-gold hover:text-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold";
  return (
    <Section id="avaliacoes" className="mesh-dark noise isolate py-20 text-white sm:py-28">
      <div className={wrap}>
        <Head dark title="Quem pediu, falou no Google" text="Nota 4,8 em 462 avaliações. Aqui vão três delas."
          action={<div className="flex gap-2"><button className={arrow} onClick={() => go(-1)} aria-label="Avaliação anterior"><ChevronLeft /></button><button className={arrow} onClick={() => go(1)} aria-label="Próxima avaliação"><ChevronRight /></button></div>} />
        <div ref={rail} role="region" aria-label="Avaliações do Google" tabIndex={0} className="-mx-5 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-4 focus-visible:outline-none [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {reviews.map((r) => (
            <motion.figure key={r} whileHover={{ y: -6 }} className="flex basis-[86%] shrink-0 snap-start flex-col justify-between rounded-2xl border border-white/10 bg-white/[.04] p-7 transition-colors hover:border-gold/50 sm:basis-[48%] lg:basis-[32%]">
              <blockquote className="font-display text-xl font-semibold leading-snug">“{r}”</blockquote>
              <figcaption className="mt-8 text-sm text-white/50">Avaliação no Google</figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </Section>
  );
}

/* ---------- Bento: 4 benefícios ---------- */
const benefits = [
  { icon: Beef, title: "Hambúrgueres e lanches caprichados", text: "Montado com capricho, do primeiro ao último pedaço.", cls: "md:col-span-4 bg-black text-white", slot: true },
  { icon: UtensilsCrossed, title: "Comida saborosa e bem servida", text: "A gente não economiza no sabor, nem na quantidade!", cls: "md:col-span-2 bg-gold text-black" },
  { icon: Flame, title: "Variedade de opções para diferentes vontades", text: "Hambúrguer, cachorro-quente, salgados e fast food. Tem pra fome grande e pra fome de petisco.", cls: "md:col-span-2 bg-white" },
  { icon: Smile, title: "Experiência agradável no ambiente", text: "O ambiente aparece nos elogios do Google. Dá pra sentar e comer com calma.", cls: "md:col-span-4 bg-white" },
];

export function Benefits() {
  return (
    <Section className="py-20 sm:py-28">
      <div className={wrap}>
        <Head title="Sabor que conquista, porção que enche" text="Quatro motivos pra o Tralalá ser a sua parada de hoje." />
        <div className="grid gap-4 md:grid-cols-6">
          {benefits.map((b, i) => (
            <Reveal key={b.title} delay={i * 0.07} className={b.cls.split(" ").filter((c) => c.startsWith("md:")).join(" ")}>
              <motion.div whileHover={{ y: -6 }} className={cn("relative h-full min-h-[14rem] overflow-hidden rounded-2xl p-7 shadow-soft", b.cls.replace(/md:\S+/g, ""))}>
                {b.slot && <ImageSlot src={img.bento} alt="Hambúrguer artesanal" className="absolute inset-y-0 right-0 hidden w-1/2 opacity-80 [mask-image:linear-gradient(to_left,black,transparent)] sm:block" />}
                <div className="relative z-10 max-w-xs">
                  <b.icon className="mb-6 size-7" aria-hidden />
                  <h3 className="font-display text-2xl font-bold leading-tight">{b.title}</h3>
                  <p className="mt-3 opacity-70">{b.text}</p>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </Section>
  );
}

/* ---------- Destaques do cardápio ---------- */
function Pick({ name, src, tag, tall, i }: { name: string; src: string; tag?: string; tall?: boolean; i: number }) {
  return (
    <Reveal delay={i * 0.08}>
      <motion.article whileHover={{ y: -8 }} className="group relative overflow-hidden rounded-2xl bg-black shadow-soft">
        <ImageSlot src={src} alt={name} label={name} className={cn("transition-transform duration-700 group-hover:scale-105", tall ? "aspect-[4/5]" : "aspect-[16/10]")} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-6 text-white">
          {tag && <span className="mb-2 inline-block rounded-full bg-gold px-3 py-1 text-xs font-bold text-black">{tag}</span>}
          <h3 className="font-display text-2xl font-bold">{name}</h3>
        </div>
      </motion.article>
    </Reveal>
  );
}

export function Highlights() {
  return (
    <Section id="destaques" className="pb-20 sm:pb-28">
      <div className={wrap}>
        <Head title="Os destaques do cardápio" text="Coxinha, Cachorro-Quente Completo e Kibbeh são os itens que o Google mostra como destaque." />
        <div className="grid gap-4 md:grid-cols-3">
          {[["Coxinha", img.coxinha], ["Cachorro-Quente Completo", img.hotdog], ["Kibbeh", img.kibbeh]].map(([n, s], i) => <Pick key={n} name={n} src={s} tag="Destaque no Google" tall i={i} />)}
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {[["Hambúrgueres", img.burgers], ["Cachorro-quente", img.hotdogs], ["Salgados", img.snacks]].map(([n, s], i) => <Pick key={n} name={n} src={s} i={i} />)}
        </div>
      </div>
    </Section>
  );
}

/* ---------- Instagram ---------- */
const posts: [string, boolean][] = [
  ["O Insano: 4 carnes no lançamento", false],
  ["Desafio do hot dog de quase 1 kg", true],
  ["O lanche de hoje é AQUI!", false],
  ["Novidade no Tralalá", true],
  ["Em troca de opinião sincera", true],
  ["Mais vídeos no perfil", true],
];

export function Insta() {
  return (
    <Section id="instagram" className="mesh-dark noise isolate py-20 text-white sm:py-28">
      <div className={wrap}>
        <Head dark title="O Tralalá no Instagram" text={`@tralala_lanches, ${brand.followers}. Lançamentos, vídeos e o movimento da casa.`}
          action={<LinkButton href={brand.insta}><Camera className="size-5" aria-hidden />Seguir no Instagram</LinkButton>} />
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
          {posts.map(([cap, video], i) => (
            <Reveal key={cap} delay={i * 0.05}>
              <motion.a href={brand.insta} target="_blank" rel="noopener noreferrer" whileHover={{ y: -6 }} className="group relative block overflow-hidden rounded-2xl">
                <ImageSlot src={img.insta[i]} alt={cap} className="aspect-[4/5] transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                {video && <Play className="absolute right-3 top-3 size-5 fill-white text-white" aria-label="Vídeo" />}
                <p className="absolute inset-x-0 bottom-0 p-4 font-display text-lg font-bold leading-tight">{cap}</p>
              </motion.a>
            </Reveal>
          ))}
        </div>
      </div>
    </Section>
  );
}

/* ---------- Cardápio ---------- */
export function Menu() {
  return (
    <Section id="cardapio" className="py-20 sm:py-28">
      <div className={wrap}>
        <Reveal>
          <div className="mesh-dark noise relative isolate overflow-hidden rounded-[2rem] p-8 text-white sm:p-14">
            <h2 className="max-w-xl font-display text-4xl font-extrabold leading-[1.02] tracking-tight sm:text-5xl">Veja tudo o que o Tralalá serve</h2>
            <p className="mt-4 max-w-lg text-lg text-white/65">Hambúrgueres, cachorro-quente, salgados e pratos de fast food no Cardápio Web da casa.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <LinkButton href={brand.menu} size="lg">Abrir o cardápio completo<ArrowUpRight className="size-5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden /></LinkButton>
              <LinkButton href={waLink()} variant="light" size="lg"><MessageCircle className="size-5" aria-hidden />Pedir pelo WhatsApp</LinkButton>
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

/* ---------- Localização ---------- */
export function Local() {
  const row = "flex gap-4";
  const ic = "mt-1 size-5 shrink-0 text-gold-deep";
  return (
    <Section id="local" className="pb-20 sm:pb-28">
      <div className={wrap}>
        <Head title="Onde o Tralalá fica" text="No bairro Ressaca, em Contagem." />
        <div className="grid gap-4 lg:grid-cols-2">
          <Reveal>
            <div className="h-full rounded-2xl border border-black/10 bg-white p-7 shadow-soft">
              <OpenPill className="mb-6" />
              <div className="space-y-5">
                <div className={row}><MapPin className={ic} aria-hidden /><p>{brand.address}</p></div>
                <div className={row}><Phone className={ic} aria-hidden /><p>{brand.phone} <span className="text-black/50">(telefone e WhatsApp)</span></p></div>
                <div className={row}><Clock className={ic} aria-hidden /><p>Segunda a sábado: 16h às 00h40<br />Domingo: 18h às 00h40</p></div>
              </div>
              <div className="mt-8 grid grid-cols-2 gap-3">
                <LinkButton href={waLink()}><MessageCircle className="size-4" aria-hidden />WhatsApp</LinkButton>
                <LinkButton href={brand.tel} variant="dark"><Phone className="size-4" aria-hidden />Ligar</LinkButton>
                <LinkButton href={routeLink} variant="outline"><Navigation className="size-4" aria-hidden />Rotas</LinkButton>
                <LinkButton href={brand.menu} variant="outline"><Beef className="size-4" aria-hidden />Cardápio</LinkButton>
              </div>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <iframe title="Mapa: Tralalá Lanches e Burguers" src={mapEmbed} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-80 w-full rounded-2xl border border-black/10 shadow-soft lg:h-full lg:min-h-[24rem]" />
          </Reveal>
        </div>
      </div>
    </Section>
  );
}

/* ---------- FAQ ---------- */
const faqs = [
  ["Qual o horário de funcionamento?", "Segunda a sábado, das 16h às 00h40. Domingo, das 18h às 00h40."],
  ["Onde fica o Tralalá?", `${brand.address}.`],
  ["Como faço pra pedir?", "Pelo WhatsApp (31) 99164-7631 ou pelo Cardápio Web. Escolhe o lanche e manda o pedido."],
  ["Onde vejo o cardápio?", "No Cardápio Web: app.cardapioweb.com/tralala_lanchonete. É só tocar em “Ver cardápio” aqui na página."],
  ["Posso pedir pelo WhatsApp?", "Pode. O número é (31) 99164-7631, o mesmo da ligação."],
  ["Que lanches vocês têm?", "Hambúrgueres, cachorro-quente, salgados e pratos de fast food. Coxinha, Cachorro-Quente Completo e Kibbeh aparecem como destaques do cardápio no Google."],
  ["Como chego até vocês?", "Toque em “Rotas” na seção de localização e o Google Maps traça o caminho até a R. Rodrigues da Cunha, 790B, no bairro Ressaca, em Contagem."],
];

export function Faq() {
  return (
    <Section id="faq" className="pb-20 sm:pb-28">
      <div className={cn(wrap, "max-w-3xl")}>
        <Head title="Dúvidas rápidas" />
        <Reveal>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map(([q, a]) => (
              <AccordionItem key={q} value={q}>
                <AccordionTrigger>{q}</AccordionTrigger>
                <AccordionContent>{a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </Section>
  );
}

/* ---------- CTA final + rodapé ---------- */
export function FinalCta() {
  return (
    <Section className="mesh-dark noise isolate py-24 text-center text-white sm:py-36">
      <div className={cn(wrap, "max-w-4xl")}>
        <Reveal>
          <h2 className="font-display text-5xl font-extrabold leading-[.98] tracking-tight sm:text-7xl">Seu próximo lanche merece ser do Tralalá.</h2>
          <p className="mx-auto mt-6 max-w-xl text-lg text-white/65">Seg a Sáb a partir das 16h, domingo a partir das 18h. Aberto até 00h40.</p>
          <div className="mt-10 flex justify-center">
            <LinkButton href={waLink()} size="lg" className="h-16 px-9 text-lg"><MessageCircle className="size-6" aria-hidden />Pedir agora pelo WhatsApp</LinkButton>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

export function Footer() {
  return (
    <footer className="bg-black py-10 text-sm text-white/50">
      <div className={cn(wrap, "flex flex-wrap justify-between gap-4")}>
        <p>© {new Date().getFullYear()} {brand.name}</p>
        <p>{brand.address}</p>
      </div>
    </footer>
  );
}
