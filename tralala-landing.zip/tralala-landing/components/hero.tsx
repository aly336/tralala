"use client";
import { motion } from "framer-motion";
import { ArrowUpRight, Clock, MessageCircle } from "lucide-react";
import { ImageSlot, LinkButton, OpenPill, Reveal, Section } from "@/components/shared";
import { img, waLink } from "@/lib/content";

export function Hero() {
  return (
    <Section id="topo" className="mesh noise isolate overflow-hidden pb-16 pt-28 sm:pb-24 sm:pt-36">
      <div className="mx-auto grid max-w-6xl items-center gap-14 px-5 lg:grid-cols-[1.05fr_.95fr]">
        <div>
          <Reveal><OpenPill /></Reveal>
          <Reveal delay={0.08}>
            <h1 className="mt-6 font-display text-[2.7rem] font-extrabold leading-[.98] tracking-tight sm:text-6xl lg:text-7xl">
              Chega de lanche pequeno e sem graça. Em Contagem, <span className="hl">o de hoje é aqui.</span>
            </h1>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-black/70">
              <span className="hl font-semibold text-black">Sabor que conquista</span>, hambúrguer caprichado e porção que enche o prato. A gente não economiza no sabor, nem na quantidade.
            </p>
          </Reveal>
          <Reveal delay={0.24} className="mt-8 flex flex-col gap-3 sm:flex-row">
            <LinkButton href={waLink()} size="lg"><MessageCircle className="size-5" aria-hidden />Pedir pelo WhatsApp</LinkButton>
            <LinkButton href="#cardapio" variant="outline" size="lg">Ver cardápio<ArrowUpRight className="size-5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden /></LinkButton>
          </Reveal>
          <Reveal delay={0.32} className="mt-8 flex flex-wrap items-center gap-x-4 gap-y-2">
            <span className="rounded-full bg-black px-4 py-2 text-sm font-semibold text-white">
              4,8 <span className="text-gold">★</span> no Google • 462 avaliações
            </span>
            <span className="text-sm text-black/60">R$ 20–40 por pessoa</span>
          </Reveal>
        </div>

        <Reveal delay={0.2} className="relative">
          <ImageSlot src={img.hero} alt="Hambúrguer artesanal do Tralalá em close" label="Foto de capa: hambúrguer em close" priority className="aspect-[4/5] rounded-[2rem] shadow-soft" />
          <div className="pointer-events-none absolute inset-0 rounded-[2rem] bg-gradient-to-t from-black/45 via-transparent to-transparent" />
          <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }} className="absolute -left-3 bottom-8 max-w-[15rem] rounded-2xl border border-white/60 bg-white/80 p-4 shadow-soft backdrop-blur-xl sm:-left-8">
            <p className="flex items-center gap-2 text-sm font-bold"><Clock className="size-4 text-gold-deep" aria-hidden />Atendimento</p>
            <p className="mt-2 text-sm leading-snug text-black/70">Seg a Sáb: 16h às 00h40<br />Dom: 18h às 00h40</p>
          </motion.div>
          <div className="absolute right-4 top-4 rounded-full bg-gold px-4 py-2 text-sm font-bold shadow-glow">O lanche de hoje é AQUI!</div>
        </Reveal>
      </div>
    </Section>
  );
}
