export const brand = {
  name: "Tralalá | Lanches e Burguers",
  phone: "(31) 99164-7631",
  tel: "tel:+5531991647631",
  address: "R. Rodrigues da Cunha, 790B - Ressaca, Contagem - MG, 32113-340",
  insta: "https://www.instagram.com/tralala_lanches/",
  menu: "https://app.cardapioweb.com/tralala_lanchonete",
  // O print do perfil mostra 16,7 mil. Ajuste aqui se o número mudar.
  followers: "mais de 16 mil seguidores",
};

export const waLink = (msg = "Oi, Tralalá! Quero fazer um pedido.") =>
  `https://wa.me/5531991647631?text=${encodeURIComponent(msg)}`;
export const routeLink = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(brand.address)}`;
export const mapEmbed = `https://www.google.com/maps?q=${encodeURIComponent(brand.address)}&output=embed`;

// Fotos: coloque arquivos em /public/images com estes nomes ou troque por URLs do Unsplash
// (images.unsplash.com já está liberado no next.config.mjs). Sem foto, aparece um bloco de reserva.
export const img = {
  hero: "/images/hero.jpg",
  bento: "/images/bento.jpg",
  coxinha: "/images/coxinha.jpg",
  hotdog: "/images/cachorro-quente.jpg",
  kibbeh: "/images/kibbeh.jpg",
  burgers: "/images/hamburgueres.jpg",
  hotdogs: "/images/hotdogs.jpg",
  snacks: "/images/salgados.jpg",
  insta: [1, 2, 3, 4, 5, 6].map((n) => `/images/insta-${n}.jpg`),
};
